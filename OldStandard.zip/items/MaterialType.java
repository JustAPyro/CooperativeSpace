package items;

public enum MaterialType {
	
	ALUMINUM, CARBON, OXYGEN, SILICON, URANIUM, LITHIUM, STEEL, HYDROGEN;
	
}
