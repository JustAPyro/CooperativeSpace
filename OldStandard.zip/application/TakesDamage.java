package application;

public interface TakesDamage {

	
	void Damage(double dmg);
	
	
	
}
