package application;

public enum Resource {

	MONEY,
	
	OXYGEN, CARBON,
	
	HEALTH, PRIMARY, SECONDARY;
	
}
