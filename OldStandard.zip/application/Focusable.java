package application;

public interface Focusable {
	public double getX();
	public double getY();
}
