package application;

public interface HasResource {

	public abstract void withdraw(Item item);
	
	public abstract void deposit(Item item);
	
}
