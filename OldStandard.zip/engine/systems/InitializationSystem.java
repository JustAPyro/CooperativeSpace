package engine.systems;

import engine.messaging.Message;

public class InitializationSystem implements SystemInterface {

    @Override
    public void handleMessage(Message msg) {

    }

    @Override
    public void sendMessage(Message msg) {

    }
}
