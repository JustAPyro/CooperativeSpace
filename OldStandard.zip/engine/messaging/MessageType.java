package engine.messaging;

public enum MessageType {
    INITIALIZE_SYSTEMS;
}
