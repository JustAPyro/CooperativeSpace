package engine.game;

public class GameEngine {

    private static GameEngine ge;

    private GameEngine() {

    }

}
