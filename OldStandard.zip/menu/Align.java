package menu;

public enum Align {
	LEFT, CENTER, RIGHT
}
