package ability;

public enum Slot {
	RED,	// Damage 
	GREEN,	// Healing
	YELLOW,	// Utility
	BLUE;	// Tanking
}
