package events;

public class PlanetInvasion extends Event{

	public PlanetInvasion(double length) {
		super(length);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void eventManage(double timeSince) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void eventEnd() {
		// TODO Auto-generated method stub
		
	}
	
	// This class is going to be used for planet invasions

}
